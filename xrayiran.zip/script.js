document.getElementById('showMessageBtn').addEventListener('click', function() {
    alert('از بازدید شما متشکریم!\nپروژه Xray iran نسخه ایران را به دوستان خود معرفی کنید.');
});
